package main.Classes;

public class User {
    private String name;
    private String accountNumber;
    private String username;
    private String password;
    private String balance;
    private String startBalance;
    private Transaction[] transactionHistory;

    public User(String name, String accountNumber, String username, String password, String balance, String startBalance, Transaction[] transactionHistory) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.username = username;
        this.password = password;
        this.balance = balance;
        this.startBalance = startBalance;
        this.transactionHistory = transactionHistory;
    }


    public String getName() {
        return name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getBalance() {
        return balance;
    }

    public Transaction[] getTransactionHistory() {
        return transactionHistory;
    }

    public String getStartBalance() {
        return startBalance;
    }
}
