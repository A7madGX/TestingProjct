package main.Classes;

public class Transaction {
    private String type;
    private String amount;
    private String forr;
    private String on;

    public Transaction(String type, String amount, String _For, String to) {
        this.type = type;
        this.amount = amount;
        this.forr = _For;
        this.on = to;
    }

    public String getType() {
        return type;
    }

    public String getAmount() {
        return amount;
    }

    public String getForr() {
        return forr;
    }

    public String getOn() {
        return on;
    }
}
