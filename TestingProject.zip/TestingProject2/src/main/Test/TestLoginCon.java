package main.Test;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import main.Classes.User;
import main.Controllers.ProfileController;
import main.Controllers.logInController;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.FileReader;

import static org.junit.jupiter.api.Assertions.fail;


public class TestLoginCon {

    logInController login = new logInController();

    @Test
    @DisplayName("Testing the getuser() function")
    void Test1() {
        User testinguser = login.getUser("ahmed", "1234", "Ahmed Osama", "89894");
        if (!testinguser.getName().equals("Ahmed Osama")) fail("name error" + " Actual is " + testinguser.getName());
        else if (!testinguser.getUsername().equals("ahmed"))
            fail("username error" + " Actual is " + testinguser.getUsername());
        else if (!testinguser.getPassword().equals("1234"))
            fail("password error" + " Actual is " + testinguser.getPassword());
        else if (!testinguser.getAccountNumber().equals("89894"))
            fail("account number error " + " Actual is " + testinguser.getAccountNumber());
        else if (!testinguser.getBalance().equals("6180.0"))
            fail("balance error" + " Actual is " + testinguser.getBalance());
        else if (!testinguser.getStartBalance().equals("1100"))
            fail("start balance error" + " Actual is " + testinguser.getStartBalance());
        else if (!testinguser.getTransactionHistory()[0].getType().equals("Deposit"))
            fail("Transaction history error" + " Actual is " + testinguser.getTransactionHistory()[0].getType());
    }

    @Test
    @DisplayName("Testing the login() function")
    void Test2() {
        String username = "john";
        String password = "4321";

        String usersFile = "src/main/DB/users.csv";
        BufferedReader reader;
        String line;
        boolean foundU = false;
        boolean foundP = false;
        String[] userT = new String[2];
        try {
            reader = new BufferedReader(new FileReader(usersFile));
            while ((line = reader.readLine()) != null) {
                String[] user = line.split(",");

                if (username.equals(user[0]) && password.equals(user[1])) {
                    foundU = true;
                    userT[0] = user[0];
                    foundP = true;
                    userT[1] = user[1];

                } else if (username.equals(user[0])  && !password.equals(user[1])) {
                    foundU = true;
                    userT[0] = user[0];
                } else if (!username.equals(user[0]) && password.equals(user[1])) {
                    foundP = true;
                    userT[1] = user[1];
                }

            }
            if (!foundU){
                fail("Username doesn't exist Expected : " + username + " Actual: " + userT[0]);
            }else if (!foundP){
                fail("Username and Password don't match Expected: " + password + " Actual: " + userT[1]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}