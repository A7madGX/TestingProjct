package main.Test;

import main.Controllers.ProfileController;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class TestProfileCon {
    ProfileController profile = new ProfileController();

    @Test
    @DisplayName("Testing the Deposit() function")
    void Test1() throws IOException {
        float amount = Float.parseFloat("1000");

        String username = null, balance = null, startBalance = null, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals("john")) {
                balance = Float.toString(Float.parseFloat(balance) + amount);

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Deposit%" + amount + "%" + "56342" + "%" + date;
            }
            pw.println(username + "," + balance + "," + startBalance + "," + transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        Scanner scanner1 = new Scanner(new File("src/main/DB/temp.csv"));
        scanner1.useDelimiter("[,\n]");
        while (scanner1.hasNext()) {
            username = scanner1.next();
            balance = scanner1.next();
            startBalance = scanner1.next();
            transactionHistory = scanner1.next();
            if (username.equals("john")) break;

        }
        if (!username.equals("john")) fail("Username error Expected: john Actual: " + username);
        else if (!balance.equals("8132.7")) fail("balance error Expected: 8132.7 actual " + balance);
        else if (!startBalance.equals("3000")) fail("start balance error Expected: 3000" + startBalance);
        scanner1.close();
    }

    @Test
    @DisplayName("Testing the withdraw function")
    void Test2() throws IOException {
        float amount = Float.parseFloat("1000");
        String username, balance = null, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);

        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals("john")) {
                balance = Float.toString(Float.parseFloat(balance) - amount);
                if (Float.parseFloat(balance) < 0) {
                    return;
                }

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Withdraw%" + amount + "%" + "56342" + "%" + date;
            }
            pw.println(username + "," + balance + "," + startBalance + "," + transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        scanner = new Scanner(new File("src/main/DB/temp.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();
            transactionHistory = scanner.next();
            if (username.equals("john")) break;
        }
        if (!balance.equals("6132.7")) fail("Balance error Expected 6132.7 Actual: " + balance);
        scanner.close();
    }

    @Test
    @DisplayName("Testing Buy() function ")
    void Test3() throws IOException {
        float amount = Float.parseFloat("1000");
        String username, balance = null, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals("john")) {
                balance = Float.toString(Float.parseFloat(balance) - amount);
                if (Float.parseFloat(balance) < 0) {
                    return;
                }

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Buy%" + amount + "%" + "Item name" + "%" + date;
            }
            pw.println(username + "," + balance + "," + startBalance + "," + transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        scanner = new Scanner(new File("src/main/DB/temp.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();
            transactionHistory = scanner.next();
            if (username.equals("john")) break;
        }
        if (!balance.equals("6132.7")) fail("balance error Expected: 6132.7 Actual: " + balance);

    }

    @Test
    @DisplayName("Testing the CheckAccountExists() function with correct input ")
    void test5() throws FileNotFoundException {
        assertEquals(profile.checkAccountExists("89894"), "ahmed");
    }

    @Test
    @DisplayName("Testing the CheckAccountExists() function with wrong input")
    void test6() throws FileNotFoundException {
        assertEquals(profile.checkAccountExists("1"), null);
        ;
    }

    @Test
    @DisplayName("Testing the Transfer function ")
    void test7() throws IOException{
        float amount = Float.parseFloat("1000");

        String username, balance = null, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals("john")) {
                balance = Float.toString(Float.parseFloat(balance) - amount);
                if (Float.parseFloat(balance) < 0) {
                    return;
                }

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Transfer%" + amount + "%" + "89894" + "%" + date;
            } else if (username.equals("ahmed")) {
                balance = Float.toString(Float.parseFloat(balance) + amount);

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Deposit%" + amount + "%" + "89894" + "%" + date;
            }
            pw.println(username + "," + balance + "," + startBalance + "," + transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        scanner = new Scanner(new File("src/main/DB/temp.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();
            transactionHistory = scanner.next();
            if(username.equals("john"))break;
        }
        if (!balance.equals("6132.7")) fail("Balance error Expected: 6132.7 Actual: " + balance);
        scanner.close();
    }
}
