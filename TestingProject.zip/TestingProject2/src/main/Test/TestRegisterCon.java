package main.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.Random;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestRegisterCon {
    @Test
    @DisplayName("Unit Testing of the file writing functionality in register() ")
    void Test1() throws IOException {
        Random rand = new Random();
        int accountNumber = rand.nextInt(99999-10000) + 10000;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);

        pw.println("username"+","+"password"+","+"name"+","+accountNumber);

        pw.flush();
        pw.close();

        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("src/main/DB/temp.csv"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        scanner.useDelimiter("[,\n]");
        String username = null, password = null, name = null, accountnumber = null;
        while(scanner.hasNext()) {
            username = scanner.next();
            password = scanner.next();
            name = scanner.next();
            accountnumber = scanner.next().strip();
        }
        assertEquals("username"+","+"password"+","+"name"+","+accountNumber,username+","+password+","+name+","+accountnumber);
    }
}
