package main.Test;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import main.Classes.Transaction;
import main.Classes.User;
import main.Controllers.ProfileController;
import main.Controllers.logInController;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.testfx.api.FxRobot;
import org.testfx.assertions.api.Assertions;
import org.testfx.framework.junit5.ApplicationExtension;
import org.testfx.framework.junit5.Start;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;

@ExtendWith(ApplicationExtension.class)

public class GuiTest {
    @FXML
    public Button logInButton;

    @FXML
    public TextField passwordInput;

    @FXML
    public TextField usernameInput;

    public static User getUser(String username, String password, String name, String account) {
        String usersFile = "src/main/DB/userinfo.csv";
        BufferedReader reader;
        String line;

        try {
            reader = new BufferedReader(new FileReader(usersFile));
            while((line = reader.readLine()) != null) {
                String[] user = line.split(",");

                if (user[0].equals(username)) {
                    Transaction[] transactions;
                    if (user.length > 3) {
                        String[] transactionStrings = user[3].split(" ");
                        transactions = new Transaction[transactionStrings.length];
                        int i = 0;
                        for (String transaction : transactionStrings) {
                            String[] tokens = transaction.split("%");
                            transactions[i] = new Transaction(tokens[0], tokens[1], tokens[2], tokens[3]);
                            i++;
                        }
                    } else {
                        transactions = new Transaction[]{};
                    }
                    return new User(name, account, username, password, user[1], user[2], transactions);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void logIn(ActionEvent actionEvent) {
        String username = usernameInput.getText();
        String password = passwordInput.getText();

        String usersFile = "src/main/DB/users.csv";
        BufferedReader reader;
        String line;

        try {
            reader = new BufferedReader(new FileReader(usersFile));
            while((line = reader.readLine()) != null) {
                String[] user = line.split(",");

                if (user[0].equals(username) && user[1].equals(password)) {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("../Resources/profile.fxml"));
                    Parent root = loader.load();

                    ProfileController profileController = loader.getController();  // Instantiating a controller with the current user.
                    User currentUser = getUser(user[0], user[1], user[2], user[3]);
                    profileController.setUser(currentUser);
                    profileController.init();

                    Stage stage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();   // Switching to the profile.fxml scene.
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();

                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void register(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../Resources/registerPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @Start
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Resources/logInPage.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        Random rand = new Random();
    }

    @Test
    @DisplayName("login gui test")
     void Test1(FxRobot robot){
        robot.clickOn("usernameInput");
        robot.write("ahmed");
        robot.clickOn("passwordInput");
        robot.write("1234");
        Assertions.assertThat(robot.lookup("usernameInput").queryAs(TextField.class)).hasText("ahmed");
    }

}


