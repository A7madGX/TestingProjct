package main.Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class registerController {
    @FXML
    private TextField usernameInput;

    @FXML
    private TextField passwordInput;

    @FXML
    private TextField nameInput;

    public void register(ActionEvent actionEvent) throws IOException {
        Random rand = new Random();
        int accountNumber = rand.nextInt(99999-10000) + 10000;

        FileWriter fw = new FileWriter("src/main/DB/users.csv", true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);

        pw.println(usernameInput.getText()+","+passwordInput.getText()+","+nameInput.getText()+","+accountNumber);

        pw.flush();
        pw.close();

        fw = new FileWriter("src/main/DB/userinfo.csv", true);
        bw = new BufferedWriter(fw);
        pw = new PrintWriter(bw);

        pw.println(usernameInput.getText()+",0,0,");

        pw.flush();
        pw.close();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../Resources/logInPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
