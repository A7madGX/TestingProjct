package main.Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import main.Classes.Transaction;
import main.Classes.User;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class logInController {
    @FXML
    public Button logInButton;

    @FXML
    public TextField passwordInput;

    @FXML
    public TextField usernameInput;

    public static User getUser(String username, String password, String name, String account) {
        String usersFile = "src/main/DB/userinfo.csv";
        BufferedReader reader;
        String line;

        try {
            reader = new BufferedReader(new FileReader(usersFile));
            while((line = reader.readLine()) != null) {
                String[] user = line.split(",");

                if (user[0].equals(username)) {
                    Transaction[] transactions;
                    if (user.length > 3) {
                        String[] transactionStrings = user[3].split(" ");
                        transactions = new Transaction[transactionStrings.length];
                        int i = 0;
                        for (String transaction : transactionStrings) {
                            String[] tokens = transaction.split("%");
                            transactions[i] = new Transaction(tokens[0], tokens[1], tokens[2], tokens[3]);
                            i++;
                        }
                    } else {
                        transactions = new Transaction[]{};
                    }
                    return new User(name, account, username, password, user[1], user[2], transactions);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void logIn(ActionEvent actionEvent) {
        String username = usernameInput.getText();
        String password = passwordInput.getText();

        String usersFile = "src/main/DB/users.csv";
        BufferedReader reader;
        String line;

        try {
            reader = new BufferedReader(new FileReader(usersFile));
            while((line = reader.readLine()) != null) {
                String[] user = line.split(",");

                if (user[0].equals(username) && user[1].equals(password)) {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("../Resources/profile.fxml"));
                    Parent root = loader.load();

                    ProfileController profileController = loader.getController();  // Instantiating a controller with the current user.
                    User currentUser = getUser(user[0], user[1], user[2], user[3]);
                    profileController.setUser(currentUser);
                    profileController.init();

                    Stage stage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();   // Switching to the profile.fxml scene.
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();

                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void register(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../Resources/registerPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
