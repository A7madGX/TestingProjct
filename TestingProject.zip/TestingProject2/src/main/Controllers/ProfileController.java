package main.Controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import main.Classes.Transaction;
import main.Classes.User;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ProfileController {
    @FXML
    private Label name;

    @FXML
    private AnchorPane depositForm;

    @FXML
    private TextField depositInput;

    @FXML
    private AnchorPane withdrawForm;

    @FXML
    private TextField withdrawInput;

    @FXML
    private AnchorPane buyForm;

    @FXML
    private TextField itemNameInput;

    @FXML
    private TextField buyAmountInput;

    @FXML
    private AnchorPane transferForm;

    @FXML
    private TextField accountNumberInput;

    @FXML
    private TextField transferAmountInput;

    @FXML
    private Label balanceLabel;

    @FXML
    private Label accountLabel;

    @FXML
    private TableView<Transaction> transactionTable;

    @FXML
    private TableColumn<Transaction, String> typeColumn;

    @FXML
    private TableColumn<Transaction, String> amountColumn;

    @FXML
    private TableColumn<Transaction, String> forColumn;

    @FXML
    private TableColumn<Transaction, String> onColumn;

    @FXML
    private LineChart<String, Number> balanceChart;

    @FXML
    private CategoryAxis transactionAxis;

    @FXML
    private NumberAxis balanceAxis;

    private User user;

    ObservableList<Transaction> transactions;

    public void init() {
        name.setText(user.getName());
        initLabels();
        initTable();
        initChart();
    }

    private void initLabels() {
        balanceLabel.setText(user.getBalance());
        accountLabel.setText(user.getAccountNumber());
    }

    private void initTable() {
        transactions = FXCollections.observableArrayList(user.getTransactionHistory());

        typeColumn.setCellValueFactory(new PropertyValueFactory<Transaction, String>("type"));
        amountColumn.setCellValueFactory(new PropertyValueFactory<Transaction, String>("amount"));
        forColumn.setCellValueFactory(new PropertyValueFactory<Transaction, String>("forr"));
        onColumn.setCellValueFactory(new PropertyValueFactory<Transaction, String>("on"));

        transactionTable.setItems(transactions);
        transactionTable.getSelectionModel().clearSelection();
    }

    private void initChart() {

        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();
        series.setName("Balance History");

        float balance = Float.parseFloat(user.getStartBalance());
        series.getData().add(new XYChart.Data<String, Number>("Start", balance));

        for (int i = 0; i < user.getTransactionHistory().length; i++) {
            Transaction transaction = user.getTransactionHistory()[i];
            int sign = transaction.getType().equals("Deposit") ? 1 : -1;
            balance += sign * Float.parseFloat(transaction.getAmount());

            series.getData().add(new XYChart.Data<String, Number>(Integer.toString(i+1), balance));
        }
        balanceChart.getData().add(series);
        balanceChart.setLegendVisible(false);
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void openDepositForm(ActionEvent actionEvent) {
        depositForm.setVisible(true);
    }

    public void openWithdrawForm(ActionEvent actionEvent) {
        withdrawForm.setVisible(true);
    }

    public void openBuyForm(ActionEvent actionEvent) {
        buyForm.setVisible(true);
    }

    public void openTransferForm(ActionEvent actionEvent) {
        transferForm.setVisible(true);
    }

    public void logOut(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../Resources/logInPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void copyTempToInfo() throws IOException {
        String username, balance, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/userinfo.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/temp.csv"));
        scanner.useDelimiter("[,\n]");

        while(scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();
            transactionHistory = scanner.next().strip();
            pw.println(username+","+balance+","+startBalance+","+transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();
    }

    public void deposit(ActionEvent actionEvent) throws IOException {
        float amount = Float.parseFloat(depositInput.getText());

        String username, balance, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while(scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals(user.getUsername())) {
                balance = Float.toString(Float.parseFloat(balance) + amount);

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Deposit%"+amount+"%"+user.getAccountNumber()+"%"+date;
            }
            pw.println(username+","+balance+","+startBalance+","+transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        copyTempToInfo();

        depositInput.clear();
        depositForm.setVisible(false);
        user = logInController.getUser(user.getUsername(), user.getPassword(), user.getName(), user.getAccountNumber());
        init();
    }

    public void withdraw(ActionEvent actionEvent) throws IOException {
        float amount = Float.parseFloat(withdrawInput.getText());

        String username, balance, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while(scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals(user.getUsername())) {
                balance = Float.toString(Float.parseFloat(balance) - amount);
                if (Float.parseFloat(balance) < 0) {
                    return;
                }

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Withdraw%"+amount+"%"+user.getAccountNumber()+"%"+date;
            }
            pw.println(username+","+balance+","+startBalance+","+transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        copyTempToInfo();

        withdrawInput.clear();
        withdrawForm.setVisible(false);
        user = logInController.getUser(user.getUsername(), user.getPassword(), user.getName(), user.getAccountNumber());
        init();
    }

    public void buy(ActionEvent actionEvent) throws IOException {
        float amount = Float.parseFloat(buyAmountInput.getText());

        String username, balance, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while(scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals(user.getUsername())) {
                balance = Float.toString(Float.parseFloat(balance) - amount);
                if (Float.parseFloat(balance) < 0) {
                    return;
                }

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Buy%"+amount+"%"+itemNameInput.getText()+"%"+date;
            }
            pw.println(username+","+balance+","+startBalance+","+transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        copyTempToInfo();

        itemNameInput.clear();
        buyAmountInput.clear();
        buyForm.setVisible(false);
        user = logInController.getUser(user.getUsername(), user.getPassword(), user.getName(), user.getAccountNumber());
        init();
    }

    public String checkAccountExists(String accountToSearch) throws FileNotFoundException {
        String username, password, name, account;
        Scanner scanner = new Scanner(new File("src/main/DB/users.csv"));
        scanner.useDelimiter("[,\n]");

        while (scanner.hasNext()) {
            username = scanner.next();
            password = scanner.next();
            name = scanner.next();
            account = scanner.next().strip();

            if (account.equals(accountToSearch)) {
                return username;
            }
        }
        return null;
    }

    public void transfer(ActionEvent actionEvent) throws IOException {
        String userToDepositTo = checkAccountExists(accountNumberInput.getText());
        if (userToDepositTo == null) {
            return;
        } else if (accountNumberInput.getText().isEmpty() && transferAmountInput.getText().isEmpty()) {
            transferForm.setVisible(false);
            return;
        }
        float amount = Float.parseFloat(transferAmountInput.getText());

        String username, balance, startBalance, transactionHistory;

        FileWriter fw = new FileWriter("src/main/DB/temp.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        Scanner scanner = new Scanner(new File("src/main/DB/userinfo.csv"));
        scanner.useDelimiter("[,\n]");

        while(scanner.hasNext()) {
            username = scanner.next();
            balance = scanner.next();
            startBalance = scanner.next();

            boolean firstTransaction = true;
            if (scanner.hasNext()) {
                transactionHistory = scanner.next();
                firstTransaction = false;
            } else {
                transactionHistory = "";
            }
            transactionHistory = transactionHistory.strip();

            if (username.equals(user.getUsername())) {
                balance = Float.toString(Float.parseFloat(balance) - amount);
                if (Float.parseFloat(balance) < 0) {
                    return;
                }

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Transfer%"+amount+"%"+accountNumberInput.getText()+"%"+date;
            } else if (username.equals(userToDepositTo)) {
                balance = Float.toString(Float.parseFloat(balance) + amount);

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDateTime now = LocalDateTime.now();
                String date = dtf.format(now);

                if (!firstTransaction) {
                    transactionHistory += " ";
                }
                transactionHistory += "Deposit%"+amount+"%"+user.getAccountNumber()+"%"+date;
            }
            pw.println(username+","+balance+","+startBalance+","+transactionHistory);
        }
        scanner.close();
        pw.flush();
        pw.close();

        copyTempToInfo();

        accountNumberInput.clear();
        transferAmountInput.clear();
        transferForm.setVisible(false);
        user = logInController.getUser(user.getUsername(), user.getPassword(), user.getName(), user.getAccountNumber());
        init();
    }
}
